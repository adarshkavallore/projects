﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Session.Clear();
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (RadioButtonList1.SelectedIndex == 0)
        {
            Response.Redirect("AdminLogin.aspx");
        }

        if (RadioButtonList1.SelectedIndex == 1)
        {
            Response.Redirect("UserLogin.aspx");
        }

        if (RadioButtonList1.SelectedIndex == -1) //-1 is the indication of none selected
        {
            RadioButtonList1.SelectedIndex = 1; //select index 2 (can also be value or text)
        }
    }
    protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}