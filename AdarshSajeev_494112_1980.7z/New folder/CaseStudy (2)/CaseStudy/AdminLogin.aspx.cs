﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void btnreset_Click(object sender, EventArgs e)
    {
        
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(@"server=INBASDPC12823;database=dbCasestudy;Integrated security=false;uid=SA;pwd=System123");
        con.Open();
        SqlCommand cmd = new SqlCommand("select * from tblRta where RtaId =@Username and RtaPassword=@Password1", con);
        cmd.Parameters.AddWithValue("@Username", txtuserid.Text);
        cmd.Parameters.AddWithValue("@Password1", txtpassword.Text);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        DataTable dt = new DataTable();
        da.Fill(dt);

        if (dt.Rows.Count > 0)
        {
          
                Session["adk"] = txtuserid.Text;
            Response.Redirect("RTAprofile.aspx?Username=" +txtuserid.Text);
         
        }
        else
        {
            ClientScript.RegisterStartupScript(Page.GetType(), "validation", "<script language='javascript'>alert('Invalid Username and Password')</script>");
        }​
        
    }
}